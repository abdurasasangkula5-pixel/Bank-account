package com.example.wallet01

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Blue = Color(0xFF1457C5)
private val Pale = Color(0xFFF3F6FC)
private val Ink = Color(0xFF17233C)

data class DemoTransaction(val title: String, val detail: String, val amount: Double, val incoming: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WalletApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletApp() {
    var balance by remember { mutableDoubleStateOf(1250.00) }
    var selected by remember { mutableStateOf("Home") }
    var showAdd by remember { mutableStateOf(false) }
    var showSend by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var recipient by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Demo wallet only — no real money or bank connection.") }
    val transactions = remember {
        mutableStateListOf(
            DemoTransaction("Welcome demo funds", "Sample balance • Today", 1250.00, true)
        )
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Blue, background = Pale, surface = Color.White)
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Wallet 0.1", fontWeight = FontWeight.Bold, color = Ink)
                            Text("INDEPENDENT DEMO WALLET", style = MaterialTheme.typography.labelSmall, color = Blue)
                        }
                    },
                    actions = {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profile",
                            modifier = Modifier.padding(end = 16.dp), tint = Blue)
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected == "Home", { selected = "Home" },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected == "History", { selected = "History" },
                        icon = { Icon(Icons.Default.History, null) }, label = { Text("History") })
                    NavigationBarItem(selected == "Profile", { selected = "Profile" },
                        icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profile") })
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(
                    balance, transactions, message,
                    onAdd = { amountText = ""; showAdd = true },
                    onSend = { amountText = ""; recipient = ""; showSend = true },
                    modifier = Modifier.padding(padding)
                )
                "History" -> HistoryScreen(transactions, Modifier.padding(padding))
                else -> ProfileScreen(Modifier.padding(padding))
            }
        }

        if (showAdd) {
            AmountDialog(
                title = "Add demo funds",
                subtitle = "Adds sample money to this device only.",
                amount = amountText,
                onAmount = { amountText = it },
                onDismiss = { showAdd = false },
                onConfirm = {
                    val value = amountText.toDoubleOrNull()
                    if (value != null && value > 0 && value <= 100000) {
                        balance += value
                        transactions.add(0, DemoTransaction("Demo cash in", "Local test transaction", value, true))
                        message = "Demo funds added. No real payment was made."
                        showAdd = false
                    } else message = "Enter an amount from 0.01 to 100,000."
                }
            )
        }

        if (showSend) {
            AlertDialog(
                onDismissRequest = { showSend = false },
                title = { Text("Send demo money") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("This only changes the sample balance on this device.")
                        OutlinedTextField(recipient, { recipient = it }, label = { Text("Recipient nickname") }, singleLine = true)
                        OutlinedTextField(amountText, { amountText = it }, label = { Text("Amount (PHP)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val value = amountText.toDoubleOrNull()
                        if (recipient.isBlank()) message = "Enter a recipient nickname."
                        else if (value == null || value <= 0 || value > balance) message = "Enter a valid amount within your demo balance."
                        else {
                            balance -= value
                            transactions.add(0, DemoTransaction("Demo transfer to $recipient", "Local test transaction", value, false))
                            message = "Demo transfer recorded locally. No money was sent."
                            showSend = false
                        }
                    }) { Text("Record demo transfer") }
                },
                dismissButton = { TextButton(onClick = { showSend = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun HomeScreen(
    balance: Double,
    transactions: List<DemoTransaction>,
    message: String,
    onAdd: () -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Blue)) {
                Column(Modifier.fillMaxWidth().padding(22.dp)) {
                    Text("DEMO WALLET BALANCE", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("₱" + String.format(Locale.US, "%,.2f", balance), color = Color.White,
                        style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Sample funds only • Not withdrawable", color = Color.White.copy(alpha = .85f))
                    Spacer(Modifier.height(18.dp))
                    Text("Account ID: DEMO-0001", color = Color.White, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4D6))) {
                Text(message, Modifier.padding(14.dp), color = Color(0xFF795500), style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton("Cash in", Icons.Default.Add, Modifier.weight(1f), onAdd)
                ActionButton("Send", Icons.Default.ArrowUpward, Modifier.weight(1f), onSend)
            }
        }
        item {
            Text("Recent activity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
        }
        items(transactions.take(5)) { tx -> TransactionRow(tx) }
        item {
            Text("DEMO ONLY — This app is not a bank, e-money issuer, or payment service. It is not affiliated with GCash. Do not enter real banking credentials or use it for real payments.",
                style = MaterialTheme.typography.labelSmall, color = Color(0xFF6C7482))
        }
    }
}

@Composable
fun ActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier.height(58.dp), shape = RoundedCornerShape(16.dp)) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(label, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TransactionRow(tx: DemoTransaction) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (tx.incoming) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                contentDescription = null, tint = if (tx.incoming) Color(0xFF16834A) else Blue,
                modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.title, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(tx.detail, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            Text((if (tx.incoming) "+" else "−") + "₱" + String.format(Locale.US, "%,.2f", tx.amount),
                fontWeight = FontWeight.Bold, color = if (tx.incoming) Color(0xFF16834A) else Ink)
        }
    }
}

@Composable
fun HistoryScreen(transactions: List<DemoTransaction>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Transaction history", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("All entries below are local demo records.", color = Color.Gray)
        transactions.forEach { TransactionRow(it) }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Default.AccountCircle, contentDescription = null, tint = Blue, modifier = Modifier.size(64.dp))
        Text("Demo User", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Account: DEMO-0001")
        Text("Wallet 0.1 is an offline demonstration. No real identity verification, bank account, or payment processing is connected.")
    }
}

@Composable
fun AmountDialog(
    title: String, subtitle: String, amount: String, onAmount: (String) -> Unit,
    onDismiss: () -> Unit, onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(subtitle)
                OutlinedTextField(amount, onAmount, label = { Text("Amount (PHP)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Add demo funds") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
