# Wallet 0.1 Android demo

This is an independent, offline Android wallet prototype. It is **not GCash** and is not a bank, e-money issuer, or payment service.

## Included
- Kotlin + Jetpack Compose Android app
- Demo balance and local-only sample transactions
- Add demo funds and record a demo transfer
- No real payments, bank connection, identity verification, or real account creation

## Build an APK
The easiest supported build path in this project is GitHub Actions:
1. Create a GitHub repository.
2. Upload the contents of this project ZIP to the repository (not the ZIP as a single file).
3. Open the repository's **Actions** tab.
4. Run the workflow named **Build Android demo APK** (or push a commit).
5. Wait for the workflow to finish.
6. Open the successful run and download the `wallet-0.1-debug-apk` artifact.
7. Extract the artifact ZIP on your phone and install the APK.

The workflow uses Gradle 8.9, JDK 17, and Android Gradle Plugin 8.7.3.

## Important
Do not use real customer funds or collect real bank passwords, PINs, or OTPs. A real financial service requires an authorized financial institution/payment partner, compliant backend, security review, and applicable Philippine regulatory approvals.
